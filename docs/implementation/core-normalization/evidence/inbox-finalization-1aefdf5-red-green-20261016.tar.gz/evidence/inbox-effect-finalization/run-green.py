import os,subprocess,pathlib,json,hashlib,datetime,xml.etree.ElementTree as ET,sys
base=pathlib.Path('/workspace/local/core-normalization-20261015');source=base/'worktrees/backend-inbox-effect-finalization';evidence=base/'evidence/inbox-effect-finalization/green-1aefdf5';evidence.mkdir();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def snapshot():
 if subprocess.check_output(['git','status','--porcelain'],cwd=source).strip():raise RuntimeError('Source must be clean')
 if subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()!=head:raise RuntimeError('Source revision changed')
 digest=hashlib.sha256()
 for n in sorted(filter(None,subprocess.check_output(['git','ls-files','-z'],cwd=source,text=True).split('\0'))):
  p=source/n;raw=os.readlink(p).encode() if p.is_symlink() else p.read_bytes();digest.update(n.encode()+b'\0'+hashlib.sha256(raw).digest())
 return digest.hexdigest()
record={'kind':'inbox-effect-finalization-green-proof/v1','status':'RUNNING','source_revision':head,'source_fingerprint_before':snapshot(),'phases':[]};secret=''
def save():(evidence/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
save()
try:
 env={k:v for k,v in os.environ.items() if not k.startswith('PLATFORM_POSTGRES_')};env['DOTNET_PROCESSOR_COUNT']='2'
 cmd=['dotnet','test','dotnet/tests/Hideakisolutions.Platform.Conformance.Tests','-m:1','--filter','FullyQualifiedName~EcpEnvelopeTests','--logger','trx;LogFileName=native.trx','--results-directory',str(evidence/'native-results')]
 p=subprocess.run(cmd,cwd=source,env=env,capture_output=True,text=True);(evidence/'native.log').write_text(p.stdout+p.stderr)
 tree=ET.parse(evidence/'native-results/native.trx');rows=tree.findall('.//t:UnitTestResult',ns);assert p.returncode==0 and len(rows)==11 and all(x.attrib['outcome']=='Passed' for x in rows)
 record['phases'].append({'name':'native-ECP','expected':11,'executed':11,'skips':0,'status':'PASS'});save()
 secret=subprocess.check_output(['pass','show','core-normalization/postgres-inbox-20261016'],text=True).splitlines()[0]
 env['PLATFORM_POSTGRES_INBOX_SCHEMA']='core_normalization_20261016_inbox';env['PLATFORM_POSTGRES_INBOX_CONNECTION']='Host=10.43.112.253;Port=5432;Database=postgres;Username=core_normalization_inbox_20261016;Password="'+secret.replace('"','""')+'";Include Error Detail=false;Timeout=10;Command Timeout=15'
 output=base/'install/inbox-finalization-1aefdf5';feed=base/'artifacts/inbox-finalization-1aefdf5'
 cmd=['python3',str(source/'scripts/contracts/verify-installed-postgresql-inbox.py'),'--source',str(source),'--output',str(output),'--artifacts',str(feed),'--expected','13']
 p=subprocess.run(cmd,cwd=source,env=env,capture_output=True,text=True);text=p.stdout+p.stderr
 if secret in text:raise RuntimeError('Secret output withheld')
 (evidence/'installed.log').write_text(text)
 if p.returncode:raise RuntimeError('Installed helper failed; see redacted log')
 value=json.loads((output/'receipt.json').read_text());assert value['status']=='PASS' and value['source_revision']==head and value['tests']['executed']==13 and value['tests']['skips']==0 and value['negative_configuration']['failed']==13
 assert all(value[k]['schema_objects']==0 and value[k]['schema_owner'] and not value[k]['administrative_flags'] for k in ['database_before','database_after'])
 record['phases'].append({'name':'installed-PG-effect-finalization','expected':13,'executed':13,'skips':0,'missing_configuration_expected_failures':13,'status':'PASS','receipt':str(output/'receipt.json'),'receipt_sha256':hashlib.sha256((output/'receipt.json').read_bytes()).hexdigest()});record['source_fingerprint_after']=snapshot();assert record['source_fingerprint_before']==record['source_fingerprint_after'];record['status']='PASS_SCOPED';record['credential_cadence']='Existing pass entry read once inside exclusive heavy-run lock after native11 and before PG13; environment only, never printed';record['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(record))
except Exception as error:
 record['status']='BLOCKED';record['failure']=str(error);save();print('BLOCKED: see external green proof logs',file=sys.stderr);sys.exit(1)
