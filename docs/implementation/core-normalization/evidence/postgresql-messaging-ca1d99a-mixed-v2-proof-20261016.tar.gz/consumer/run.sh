#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT=/workspace/local/sdk/dotnet TMPDIR=/build/tmp DOTNET_PROCESSOR_COUNT=2 MSBUILDDISABLENODEREUSE=1 DOTNET_CLI_USE_MSBUILD_SERVER=0 UseSharedCompilation=false
export PATH=/workspace/local/sdk/dotnet:/home/annonymous/.local/bin:/usr/local/bin:/usr/bin:/bin
export NUGET_PACKAGES=/workspace/local/core-normalization-20261015/install/postgresql-messaging-ca1d99a-mixed/packages
cd /workspace/local/core-normalization-20261015/install/postgresql-messaging-ca1d99a-mixed-v2
dotnet restore Mixed.csproj --configfile NuGet.Config -m:1 > restore.log 2>&1
dotnet build Mixed.csproj -c Release --no-restore -m:1 -p:UseSharedCompilation=false > build.log 2>&1
dotnet bin/Release/net10.0/Mixed.dll audit-first > run-audit-first.log 2>&1
dotnet bin/Release/net10.0/Mixed.dll ecp-first > run-ecp-first.log 2>&1
