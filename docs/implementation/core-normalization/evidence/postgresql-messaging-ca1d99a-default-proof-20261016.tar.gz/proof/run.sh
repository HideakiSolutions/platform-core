#!/usr/bin/env bash
set -euo pipefail
export DOTNET_PROCESSOR_COUNT=2 MSBUILDDISABLENODEREUSE=1 DOTNET_CLI_USE_MSBUILD_SERVER=0 UseSharedCompilation=false
export ECP_CONTRACTS_ROOT=/workspace/local/core-normalization-20261015/worktrees/backend-postgresql-messaging-integration
proof_dir=/workspace/local/core-normalization-20261015/evidence/postgresql-messaging-ca1d99a
feed_dir=/workspace/local/core-normalization-20261015/artifacts/postgresql-messaging-ca1d99a-dotnet
consumer_dir=/workspace/local/core-normalization-20261015/install/postgresql-messaging-ca1d99a-dotnet
cd "$ECP_CONTRACTS_ROOT"
if [ "$(git rev-parse HEAD)" != ca1d99ac0415ee6e0a7ba813c41ae5cfc5490fee ] || [ -n "$(git status --porcelain --untracked-files=all)" ]; then exit 31; fi
git rev-parse HEAD > "$proof_dir/source-head.txt"
npm ci --ignore-scripts --no-audit --no-fund > "$proof_dir/root-install.log" 2>&1
npm run contracts:verify > "$proof_dir/vendor.log" 2>&1
npm run validate:wave2-intakes > "$proof_dir/intakes.log" 2>&1
actionlint .github/workflows/*.yml > "$proof_dir/actionlint.log" 2>&1
cd dotnet
dotnet restore BackendCore.Dotnet.sln -m:1 > "$proof_dir/restore.log" 2>&1
dotnet build BackendCore.Dotnet.sln -c Release --no-restore -m:1 -p:UseSharedCompilation=false > "$proof_dir/build.log" 2>&1
dotnet test BackendCore.Dotnet.sln -c Release --no-build -m:1 --logger 'trx;LogFilePrefix=source' --results-directory "$proof_dir/source-results" > "$proof_dir/source.log" 2>&1
python3 "$proof_dir/verify-source-results.py" > "$proof_dir/source-validation.log" 2>&1
dotnet pack BackendCore.Dotnet.sln -c Release --no-build -m:1 -p:PackageOutputPath="$feed_dir" > "$proof_dir/pack.log" 2>&1
cd ..
PYTHONOPTIMIZE=2 python3 scripts/contracts/verify-installed-dotnet.py --root "$ECP_CONTRACTS_ROOT" --artifacts "$feed_dir" --output "$consumer_dir" --expected 977 --expected-projects 42 > "$proof_dir/installed.log" 2>&1
if [ "$(git rev-parse HEAD)" != ca1d99ac0415ee6e0a7ba813c41ae5cfc5490fee ] || [ -n "$(git status --porcelain --untracked-files=all)" ]; then exit 32; fi
