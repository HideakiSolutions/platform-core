from pathlib import Path
import hashlib,json,base64,subprocess,tarfile,shutil
b=Path('/workspace/local/core-normalization-20261015');e=b/'evidence/postgresql-messaging-ca1d99a';consumer=b/'install/postgresql-messaging-ca1d99a-dotnet';source=b/'worktrees/backend-postgresql-messaging-integration'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
if revision!='ca1d99ac0415ee6e0a7ba813c41ae5cfc5490fee' or subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=source):raise RuntimeError('Source changed')
shutil.copy2(consumer/'receipt.json',e/'installed-receipt.json')
receipt=json.loads((e/'installed-receipt.json').read_text());sreceipt=json.loads((e/'source-receipt.json').read_text())
for r in [receipt,sreceipt]:
 if r['status']!='PASS' or r['cases_executed']!=977 or r['test_projects_executed']!=42 or r['skips']!=0:raise RuntimeError('Profile did not pass')
libs={};assets=sorted((consumer/'dotnet/tests').glob('*/obj/project.assets.json'))
for asset in assets:
 for key,lib in json.loads(asset.read_bytes())['libraries'].items():
  if lib['type']!='package':continue
  name,version=key.rsplit('/',1);cached=consumer/'packages'/name.lower()/version.lower()/(name.lower()+'.'+version.lower()+'.nupkg')
  actual512=base64.b64encode(hashlib.sha512(cached.read_bytes()).digest()).decode()
  metadata=json.loads((cached.parent/'.nupkg.metadata').read_bytes())
  sidecar=(cached.parent/(cached.name+'.sha512')).read_text().strip()
  item={'id':name,'version':version,'archive_sha256':sha(cached),'raw_archive_sha512':actual512,'archive_sha512_sidecar':sidecar,'assets_sha512':lib['sha512'],'metadata_contentHash':metadata['contentHash'],'raw_archive_and_sidecar_equal':actual512==sidecar,'assets_and_metadata_equal':lib['sha512']==metadata['contentHash'],'raw_archive_and_assets_field_equal':actual512==lib['sha512'],'path':str(cached),'registry_origin_attestation':'NOT_ATTESTED'}
  if key in libs and libs[key]!=item:raise RuntimeError('Inconsistent observed dependency identity')
  libs[key]=item
(e/'restored-dependencies.json').write_text(json.dumps({'source_revision':revision,'dimension':'observed-default-installed-test-dependencies','status':'OBSERVED_NOT_REGISTRY_ORIGIN_ATTESTATION','count':len(libs),'note':'NuGet assets.sha512 and metadata.contentHash are recorded separately from raw archive SHA512 and archive.sha512 sidecar. No equality between these distinct fields is imposed. Own core artifacts retain the required byte-exact feed SHA256 verification in installed-receipt.json.','libraries':sorted(libs.values(),key=lambda v:(v['id'].lower(),v['version']))},indent=2)+'\n')
archivefiles=[]
for item in receipt['artifacts']:
 p=Path(item['artifact'])
 if sha(p)!=item['sha256']:raise RuntimeError('Core feed artifact changed')
 archivefiles.append(p)
if len(archivefiles)!=43 or len(receipt['selected_installed_packages'])!=42:raise RuntimeError('Artifact/default installation profile mismatch')
(e/'closure-summary.json').write_text(json.dumps({'source_revision':revision,'source_tree':sreceipt['source_tree'],'status':'PASS','source_cases':977,'source_projects':42,'installed_cases':977,'installed_projects':42,'skips':0,'packed_archives':len(archivefiles),'default_installed_core_package_ids':len(receipt['selected_installed_packages']),'observed_dependency_archives':len(libs),'limits':['Default profile only; separate PostgreSQL Inbox and transport proofs remain separate','Local artifact installation; no registry publication/adoption or contract admission','No reclassification of historical audit interoperability failures','External dependency field inventory is observation, not registry-origin attestation'],'source_receipt_sha256':sha(e/'source-receipt.json'),'installed_receipt_sha256':sha(e/'installed-receipt.json')},indent=2)+'\n')
members=[]
for p in sorted(e.rglob('*')):
 if p.is_file() and (p.parent.name=='source-results' or p.name in {'run.sh','verify-source-results.py','seal-proof.py','source-head.txt','root-install.log','vendor.log','intakes.log','actionlint.log','restore.log','build.log','source.log','source-validation.log','source-receipt.json','pack.log','installed.log','installed-receipt.json','restored-dependencies.json','closure-summary.json','runtime.log'}):members.append((p,'proof/'+str(p.relative_to(e))))
for p in sorted(consumer.glob('*.log')):members.append((p,'installed-logs/'+p.name))
for p in sorted((consumer/'TestResults').rglob('*.trx')):members.append((p,'installed-results/'+str(p.relative_to(consumer/'TestResults'))))
for p in assets:members.append((p,'installed-assets/'+str(p.relative_to(consumer/'dotnet/tests'))))
for p in archivefiles:members.append((p,'artifacts/'+p.name))
mixed=b/'install/postgresql-messaging-ca1d99a-mixed'
for name in ['Mixed.csproj','Program.cs','golden.json','NuGet.Config','run.sh','restore.log','build.log','run.log','receipt.json','artifact-verification.json','verify.py','obj/project.assets.json']:
 p=mixed/name
 if not p.is_file():raise RuntimeError('Missing mixed proof member '+name)
 members.append((p,'mixed-schema-probe/'+name))
members.append((source/'scripts/contracts/verify-installed-dotnet.py','validators/verify-installed-dotnet.py'))
manifest={'schema_version':1,'source_revision':revision,'status':'PASS_scoped_dotnet_default_profile','members':[{'path':name,'bytes':p.stat().st_size,'sha256':sha(p)} for p,name in members]}
with tarfile.open(e/'proof.tar.gz','w:gz') as tar:
 for p,name in members:tar.add(p,arcname=name,recursive=False)
manifest['archive']={'path':'proof.tar.gz','bytes':(e/'proof.tar.gz').stat().st_size,'sha256':sha(e/'proof.tar.gz')}
(e/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'status':'PASS','cases':977,'projects':42,'packed':43,'installed_core_ids':42,'archive':manifest['archive'],'manifest_sha256':sha(e/'manifest.json')},indent=2))
