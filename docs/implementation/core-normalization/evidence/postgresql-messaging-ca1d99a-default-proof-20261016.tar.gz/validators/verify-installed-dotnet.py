"""Build an isolated test consumer from existing NuGet artifacts; never publish.

The explicit source root contributes only test/example fixtures and schemas.
Production libraries resolve exclusively as PackageReference from the local feed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile


def digest(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()



def source_snapshot(source):
    status = subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=source)
    if status:
        raise ValueError('Source checkout must be clean, including untracked files')
    revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
    tracked = set(os.fsdecode(raw) for raw in subprocess.check_output(['git', 'ls-files', '-z'], cwd=source).split(b'\0') if raw)
    def check_fixture(path):
        relative = path.relative_to(source)
        if path.is_symlink() or any(parent.is_symlink() for parent in path.parents if parent.is_relative_to(source)):
            raise ValueError('Symlink copied fixture input: ' + str(relative))
        if path.is_file() and relative.as_posix() not in tracked:
            raise ValueError('Ignored or untracked fixture input is not revision-bound: ' + str(relative))
    for directory in ('dotnet/tests', 'dotnet/examples', 'contracts/vendor', 'scripts/contracts'):
        base = source / directory
        check_fixture(base)
        for path in base.rglob('*'):
            parts = path.relative_to(base).parts
            if directory.startswith('dotnet/') and any(part in ('bin', 'obj', '.git', 'TestResults') or part.endswith('.log') for part in parts):
                continue
            if directory == 'scripts/contracts' and '__pycache__' in parts:
                continue
            check_fixture(path)
    for module in source.iterdir():
        if module.name not in ('contracts', 'dotnet', 'node_modules') and module.is_dir():
            for schema in (module / 'contracts').glob('*.schema.json'):
                check_fixture(schema)
    for pointer in (source / 'dotnet/src').glob('*/.platform-capability.json'):
        check_fixture(pointer)
    files = {}
    for raw in subprocess.check_output(['git', 'ls-files', '-z'], cwd=source).split(b'\0'):
        if not raw:
            continue
        name = os.fsdecode(raw)
        path = source / name
        if path.is_symlink() or not path.is_file():
            raise ValueError('Non-file/symlink tracked input: ' + name)
        files[name] = digest(path)
    return {'revision': revision, 'files': files}


def verify_results(reports, expected_projects, expected_cases):
    """One fresh, identity-checked TRX per selected project; stdout is not proof."""
    if expected_projects <= 0 or expected_cases <= 0 or len(reports) != expected_projects:
        raise ValueError('Installed project selection differs from the pinned profile')
    rows, seen_cases = [], set()
    ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
    for project, report in reports.items():
        root = ET.parse(report).getroot()
        if root.tag != '{' + ns['t'] + '}TestRun':
            raise ValueError('Invalid TRX root')
        summaries = root.findall('t:ResultSummary', ns)
        if len(summaries) != 1 or summaries[0].get('outcome') != 'Completed':
            raise ValueError('TRX run did not complete')
        counters = summaries[0].findall('t:Counters', ns)
        results = root.findall('t:Results/t:UnitTestResult', ns)
        definitions = root.findall('t:TestDefinitions/t:UnitTest', ns)
        entries = root.findall('t:TestEntries/t:TestEntry', ns)
        if len(counters) != 1 or not results:
            raise ValueError('Missing or empty TRX results')
        c = counters[0].attrib
        if any(int(c.get(key, '-1')) != len(results) for key in ('total', 'executed', 'passed')):
            raise ValueError('TRX counters differ from executed cases')
        if any(int(value) != 0 for key, value in c.items() if key not in ('total', 'executed', 'passed')):
            raise ValueError('TRX contains failed/skipped/incomplete cases')
        defs = {d.get('id'): d for d in definitions}
        if len(defs) != len(definitions) or not defs:
            raise ValueError('Duplicate or missing TRX definitions')
        result_ids, executions, identities = set(), set(), []
        for result in results:
            test_id, execution = result.get('testId'), result.get('executionId')
            if not test_id or not execution or execution in executions or test_id in result_ids:
                raise ValueError('Duplicate or missing TRX result identity')
            definition = defs.get(test_id)
            method = definition.find('t:TestMethod', ns) if definition is not None else None
            if method is None or result.get('outcome') != 'Passed':
                raise ValueError('Missing definition or non-passing TRX result')
            assembly = method.get('codeBase', '').replace(chr(92), '/').rsplit('/', 1)[-1]
            if assembly != Path(project).stem + '.dll':
                raise ValueError('TRX belongs to a different selected project')
            identity = (project, method.get('className'), method.get('name'), result.get('testName'))
            if not all(identity) or identity in seen_cases:
                raise ValueError('Duplicate or missing executed case identity')
            linked = definition.find('t:Execution', ns)
            if linked is None or linked.get('id') != execution:
                raise ValueError('TRX execution does not match definition')
            seen_cases.add(identity); result_ids.add(test_id); executions.add(execution)
            identities.append({'class': identity[1], 'method': identity[2], 'name': identity[3], 'test_id': test_id, 'execution_id': execution})
        if set(defs) != result_ids or len(entries) != len(results) or {(e.get('testId'), e.get('executionId')) for e in entries} != {(r.get('testId'), r.get('executionId')) for r in results}:
            raise ValueError('TRX definitions/entries/results do not correspond')
        rows.append({'project': project, 'report': str(report), 'sha256': digest(report), 'cases': identities, 'count': len(results)})
    if len(seen_cases) != expected_cases:
        raise ValueError('Installed case count differs from the pinned profile')
    return rows


def main():
    validator_bytes = Path(__file__).read_bytes()
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--artifacts', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expected', type=int, required=True)
    parser.add_argument('--expected-projects', type=int, required=True)
    args = parser.parse_args()
    if args.expected <= 0 or args.expected_projects <= 0:
        raise ValueError('Expected projects and cases must be positive')
    source, feed, output = (p.resolve() for p in (args.root, args.artifacts, args.output))
    if output == source or output.is_relative_to(source) or source.is_relative_to(output):
        raise ValueError('Consumer must be independent of the source checkout')
    if any((parent / '.git').exists() for parent in (output, *output.parents)):
        raise ValueError('Consumer must be outside every checkout')
    snapshot_before = source_snapshot(source)
    output.mkdir(parents=True, exist_ok=False)
    packages = {}
    evidence = []
    source_revision = snapshot_before['revision']
    for archive in sorted(feed.glob('*.nupkg')):
        with zipfile.ZipFile(archive) as contents:
            nuspec = next(name for name in contents.namelist() if name.endswith('.nuspec'))
            tree = ET.fromstring(contents.read(nuspec))
            metadata = next(item for item in tree if item.tag.rsplit('}', 1)[-1] == 'metadata')
            values = {item.tag.rsplit('}', 1)[-1]: item.text for item in metadata}
            repository = next((item.attrib for item in metadata if item.tag.rsplit('}', 1)[-1] == 'repository'), {})
        if values['id'] in packages:
            raise ValueError('Duplicate artifact identity')
        packages[values['id']] = values['version']
        artifact_revision = repository.get('commit')
        if artifact_revision:
            subprocess.run(['git', 'diff', '--exit-code', '--quiet', artifact_revision, source_revision, '--',
                            'dotnet/src/' + values['id'], 'dotnet/Directory.Build.props', 'dotnet/Directory.Build.targets', 'dotnet/Directory.Packages.props'],
                           cwd=source, check=True)
        evidence.append({'package': values['id'], 'version': values['version'], 'sha256': digest(archive), 'artifact': str(archive),
                         'repository_metadata': repository, 'source_equivalence': 'verified' if artifact_revision else 'NOT_VERIFIED_missing_repository_commit'})
    if not packages:
        raise ValueError('No NuGet artifacts; cannot approve empty installation')
    ignore = shutil.ignore_patterns('bin', 'obj', '.git', '*.log', 'TestResults')
    for directory in ('tests', 'examples'):
        shutil.copytree(source / 'dotnet' / directory, output / 'dotnet' / directory, ignore=ignore)
    shutil.copy2(source / 'dotnet/Directory.Build.props', output / 'dotnet/Directory.Build.props')
    shutil.copy2(source / 'LICENSE', output / 'LICENSE')
    artifact_hashes = {item['package'].lower(): item['sha256'] for item in evidence}
    references = 0
    used = set()
    for project in (output / 'dotnet').rglob('*.csproj'):
        tree = ET.parse(project)
        changed = False
        for reference in tree.iter('ProjectReference'):
            path = reference.get('Include', '').replace('\\', '/')
            if '/src/' not in path:
                continue
            package = Path(path).stem
            if package not in packages:
                raise ValueError('Required core artifact missing: ' + package)
            reference.tag = 'PackageReference'
            reference.attrib.clear()
            reference.set('Include', package)
            reference.set('Version', packages[package])
            references += 1
            used.add(package)
            changed = True
        if changed:
            tree.write(project, encoding='unicode', xml_declaration=False)
    if not references:
        raise ValueError('No core dependencies selected for installation')
    if (output / 'dotnet/src').exists():
        raise ValueError('Production source must not exist in installed consumer')
    configuration = ET.Element('configuration')
    sources = ET.SubElement(configuration, 'packageSources')
    ET.SubElement(sources, 'clear')
    ET.SubElement(sources, 'add', key='local-artifacts', value=str(feed))
    ET.SubElement(sources, 'add', key='public-test-dependencies', value='https://api.nuget.org/v3/index.json')
    mappings = ET.SubElement(configuration, 'packageSourceMapping')
    local = ET.SubElement(mappings, 'packageSource', key='local-artifacts')
    for package in sorted(packages):
        ET.SubElement(local, 'package', pattern=package)
    public = ET.SubElement(mappings, 'packageSource', key='public-test-dependencies')
    ET.SubElement(public, 'package', pattern='*')
    ET.ElementTree(configuration).write(output / 'NuGet.Config', encoding='unicode')
    fixture = output / 'contract-fixture'
    shutil.copy2(source / 'ecp-contracts.lock.json', output / 'source-contracts.lock.json')
    fixture.mkdir()
    shutil.copy2(source / 'ecp-contracts.lock.json', fixture / 'ecp-contracts.lock.json')
    shutil.copytree(source / 'contracts/vendor', fixture / 'contracts/vendor')
    shutil.copytree(source / 'scripts/contracts', fixture / 'scripts/contracts', ignore=shutil.ignore_patterns('__pycache__'))
    for module in source.iterdir():
        if module.name in ('contracts', 'dotnet', 'node_modules') or not module.is_dir():
            continue
        for schema in (module / 'contracts').glob('*.schema.json'):
            target = fixture / schema.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(schema, target)
    pointer_fixtures = []
    for pointer in (source / 'dotnet/src').glob('*/.platform-capability.json'):
        target = fixture / pointer.relative_to(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(pointer, target)
        pointer_fixtures.append({'path': str(pointer.relative_to(source)), 'sha256': digest(target)})
    env = {**os.environ, 'ECP_CONTRACTS_ROOT': str(fixture), 'DOTNET_CLI_UI_LANGUAGE': 'en'}
    commands = []
    def run(command, name):
        commands.append(command)
        result = subprocess.run(command, cwd=output, env=env, capture_output=True, text=True)
        (output / name).write_text(result.stdout + result.stderr)
        if result.returncode:
            raise ValueError(f'Command failed ({result.returncode}); see {output / name}')
        return result.stdout
    run(['dotnet', 'new', 'sln', '--format', 'sln', '--name', 'Installed'], 'solution.log')
    projects = sorted(str(p.relative_to(output)) for p in (output / 'dotnet/tests').glob('*/*.csproj'))
    if len(projects) != args.expected_projects:
        raise ValueError('Installed project selection differs from the pinned profile')
    run(['dotnet', 'sln', 'Installed.sln', 'add', *projects], 'projects.log')
    reports, logs = {}, []
    for index, project in enumerate(projects):
        directory = output / 'TestResults' / str(index)
        run(['dotnet', 'test', project, '-m:1', '--verbosity', 'minimal',
             '--logger', 'trx;LogFileName=results.trx', '--results-directory', str(directory),
             '-p:RestorePackagesPath=' + str(output / 'packages')], f'tests-{index}.log')
        if sorted(directory.rglob('*.trx')) != [directory / 'results.trx']:
            raise ValueError('Expected exactly one fresh TRX per selected project')
        reports[project] = directory / 'results.trx'
        logs.append((output / f'tests-{index}.log').read_text())
    (output / 'tests.log').write_text('\n'.join(logs))
    rows = verify_results(reports, args.expected_projects, args.expected)
    assets = list((output / 'dotnet/tests').glob('*/obj/project.assets.json'))
    installed = set()
    for asset in assets:
        value = json.loads(asset.read_bytes())
        for name, library in value['libraries'].items():
            package = name.rsplit('/', 1)[0]
            if package in packages:
                if library['type'] != 'package':
                    raise ValueError('Source consumption disguised as package: ' + package)
                version = name.rsplit('/', 1)[1]
                archive = output / 'packages' / package.lower() / version.lower() / (package.lower() + '.' + version.lower() + '.nupkg')
                if digest(archive) != artifact_hashes[package.lower()]:
                    raise ValueError('Restored package differs from evidence: ' + package)
                installed.add(package)
    if not used <= installed:
        raise ValueError('Some selected references did not resolve as installed artifacts')
    if Path(__file__).read_bytes() != validator_bytes:
        raise ValueError('Validator changed during execution')
    snapshot_after = source_snapshot(source)
    if snapshot_before != snapshot_after:
        raise ValueError('Source HEAD or tracked inputs changed during execution')
    receipt = {'kind': 'isolated-installed-dotnet-evidence', 'dimension': 'local-artifact-installation-and-default-test-suite', 'status': 'PASS',
               'test_source_revision': source_revision, 'source_snapshot_before': snapshot_before, 'source_snapshot_after': snapshot_after, 'project_results': rows, 'pointer_fixtures': pointer_fixtures, 'validator_sha256': digest(Path(__file__).resolve()),
               'runtime': subprocess.check_output(['dotnet', '--version'], text=True).strip(),
               'artifacts': evidence, 'selected_installed_packages': sorted(installed), 'references_replaced': references, 'restored_archive_integrity': 'verified',
               'test_projects_expected': args.expected_projects, 'test_projects_executed': len(rows), 'cases_executed': sum(row['count'] for row in rows),
               'cases_expected': args.expected, 'skips': 0, 'log_sha256': digest(output / 'tests.log'), 'commands': commands,
               'limits': ['Registry installation not claimed', 'Broker/database integration profiles are not selected by the default suite', 'No deployment or publication']}
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in ('status', 'test_projects_executed', 'cases_executed', 'skips')}))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, ET.ParseError, subprocess.CalledProcessError) as error:
        print('BLOCKED: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
