using System.Text;
using System.Text.Json;
using System.Security.Cryptography;
using Hideakisolutions.Platform.Auditing;
using Hideakisolutions.Platform.Messaging.Inbox.PostgreSql;
using Hideakisolutions.Platform.Messaging.Inbox.V2;
using Hideakisolutions.Platform.Messaging.Outbox.PostgreSql;
using Hideakisolutions.Platform.Messaging.Outbox.V2;
using Npgsql;
var golden=JsonDocument.Parse(File.ReadAllText("golden.json")).RootElement;
var results=new List<object>();
await using var data=NpgsqlDataSource.Create("Host=127.0.0.1;Port=1;Database=probe;Username=probe;Timeout=1;Pooling=false");
var inbox=new PostgreSqlInboxLeaseStore(data,"mixed_probe");
var outbox=new PostgreSqlOutboxLeaseStore(data,"mixed_probe");
var id=Guid.Parse("c21a58fe-1e10-414b-a566-c077609514ce");
void Audit(string caseId){var signed=AuditJcsV1.Sign(golden.GetProperty("raw").GetString()!);if(signed.Hash!=golden.GetProperty("hash").GetString()||signed.CanonicalUtf8!=golden.GetProperty("canonical_utf8").GetString()||signed.CanonicalHex!=golden.GetProperty("canonical_hex").GetString()||!AuditJcsV1.Verify(signed.EntryJson))throw new Exception("Audit golden mismatch");results.Add(new{id=caseId,status="passed",hash=signed.Hash});}
async Task Invalid(string caseId,Func<Task> operation){try{await operation();throw new Exception("Invalid envelope accepted");}catch(ArgumentException e) when(e.ParamName=="bytes"&&e.Message.StartsWith("ECP envelope structural contract violation.",StringComparison.Ordinal)){results.Add(new{id=caseId,status="passed",exception=e.GetType().FullName,message=e.Message});}}
Task Inbox(string caseId)=>Invalid(caseId,async()=>{await inbox.TryAcquireAsync(new InboxLeaseRequestV2(new InboxIdentity("tenant","consumer",id),Encoding.UTF8.GetBytes("{}"),TimeSpan.FromSeconds(10),2));});
async Task Outbox(string caseId){bool called=false;await Invalid(caseId,async()=>{await outbox.EnqueueWithFactAsync(new OutboxEnqueueV2(new OutboxIdentityV2("tenant","consumer",id),Encoding.UTF8.GetBytes("{}"),2),(_,_)=>{called=true;return Task.CompletedTask;});});if(called)throw new Exception("Persistence callback invoked");}
Audit("audit-before-ecp");await Inbox("inbox-after-audit");await Outbox("outbox-after-audit");await Outbox("outbox-before-audit");await Inbox("inbox-before-audit");Audit("audit-after-ecp");
var assemblies=new[]{typeof(AuditJcsV1).Assembly,typeof(PostgreSqlInboxLeaseStore).Assembly,typeof(PostgreSqlOutboxLeaseStore).Assembly,typeof(Json.Schema.JsonSchema).Assembly}.Select(a=>new{name=a.GetName().Name,version=a.GetName().Version?.ToString(),sha256=Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(a.Location))),resources=a.GetManifestResourceNames().Select(n=>{using var s=a.GetManifestResourceStream(n)!;return new{name=n,sha256=Convert.ToHexStringLower(SHA256.HashData(s))};}).ToArray()}).ToArray();
if(results.Count!=6)throw new Exception("Missing cases");
File.WriteAllText("receipt.json",JsonSerializer.Serialize(new{profile="backend-core/dotnet-mixed-schema-order/v1",revision="ca1d99ac0415ee6e0a7ba813c41ae5cfc5490fee",expected=6,executed=results.Count,results,assemblies,limits="Single process, sequential orders; no SQL, broker, concurrency or global hermeticity proof."},new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine("PASS 6/6 mixed schema order cases");
