from pathlib import Path
import json,hashlib,zipfile
b=Path('/workspace/local/core-normalization-20261015');p=b/'install/postgresql-messaging-ca1d99a-mixed';r=json.loads((p/'receipt.json').read_text())
assert r['expected']==r['executed']==6 and len({c['id'] for c in r['results']})==6 and all(c['status']=='passed' for c in r['results'])
assert r['revision']=='ca1d99ac0415ee6e0a7ba813c41ae5cfc5490fee'
resources={a['name']:{i['name']:i['sha256'] for i in a['resources']} for a in r['assemblies']}
for name in ['Inbox','Outbox']:
 assert resources['Hideakisolutions.Platform.Messaging.'+name+'.PostgreSql']['EcpEnvelope.schema.json']=='3be4fadf2078620185abb0d97002f90595dce82bffba674ca66da8559220a002'
assert resources['Hideakisolutions.Platform.Auditing']['AuditJcsV1.audit-event.schema.json']=='36fa079f9c879db41f2eb5c4710e1cbc1f69f0a6941a738ff50e5f0d4b1bc7a8'
assert resources['Hideakisolutions.Platform.Auditing']['AuditJcsV1.audit-chain-jcs-v1.schema.json']=='9fc7df505fa0d77b19546478a892ead6ff4a9f64d4e782d00cbb0db9faabb626'
assets=json.loads((p/'obj/project.assets.json').read_text());assert 'JsonSchema.Net/9.4.0' in assets['libraries']
feed=b/'artifacts/postgresql-messaging-ca1d99a-dotnet';verified=[]
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
for key,lib in assets['libraries'].items():
 name,version=key.rsplit('/',1)
 if not name.startswith('Hideakisolutions.Platform.'):continue
 archive=p/'packages'/name.lower()/version.lower()/(name.lower()+'.'+version.lower()+'.nupkg')
 artifact=feed/(name+'.'+version+'.nupkg')
 assert sha(archive)==sha(artifact)
 with zipfile.ZipFile(archive) as z:
  for member in z.namelist():
   if member.endswith('.dll'):
    filename=member.rsplit('/',1)[-1];installed=p/'bin/Release/net10.0'/filename
    assert hashlib.sha256(z.read(member)).hexdigest()==sha(installed)
 verified.append({'id':name,'version':version,'sha256':sha(archive)})
assert {v['id'] for v in verified}>={'Hideakisolutions.Platform.Auditing','Hideakisolutions.Platform.Messaging.Inbox.PostgreSql','Hideakisolutions.Platform.Messaging.Outbox.PostgreSql'}
(p/'artifact-verification.json').write_text(json.dumps({'status':'PASS','revision':r['revision'],'profile':r['profile'],'cases':6,'jsonschema_package':'9.4.0','own_packages_verified_byte_exact':verified,'limits':r['limits']},indent=2)+'\n')
print('PASS mixed cases 6, exact local artifacts and embedded resources')
