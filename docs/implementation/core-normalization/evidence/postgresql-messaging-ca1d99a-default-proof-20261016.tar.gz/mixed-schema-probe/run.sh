#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT=/workspace/local/sdk/dotnet TMPDIR=/build/tmp DOTNET_PROCESSOR_COUNT=2 MSBUILDDISABLENODEREUSE=1 DOTNET_CLI_USE_MSBUILD_SERVER=0 UseSharedCompilation=false
export PATH=/workspace/local/sdk/dotnet:/home/annonymous/.local/bin:/usr/local/bin:/usr/bin:/bin
export NUGET_PACKAGES=/workspace/local/core-normalization-20261015/install/postgresql-messaging-ca1d99a-mixed/packages
cd /workspace/local/core-normalization-20261015/install/postgresql-messaging-ca1d99a-mixed
python3 - <<'CHECK'
from pathlib import Path
import json,subprocess
b=Path('/workspace/local/core-normalization-20261015')
for p in [b/'evidence/postgresql-messaging-ca1d99a/source-receipt.json',b/'install/postgresql-messaging-ca1d99a-dotnet/receipt.json']:
 r=json.loads(p.read_text());assert r['status']=='PASS' and r['cases_executed']==977 and r['test_projects_executed']==42 and r['skips']==0
s=b/'worktrees/backend-postgresql-messaging-integration'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()=='ca1d99ac0415ee6e0a7ba813c41ae5cfc5490fee'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=s)
CHECK
dotnet restore Mixed.csproj --configfile NuGet.Config -m:1 > restore.log 2>&1
dotnet build Mixed.csproj -c Release --no-restore -m:1 -p:UseSharedCompilation=false > build.log 2>&1
dotnet run --project Mixed.csproj -c Release --no-build > run.log 2>&1
