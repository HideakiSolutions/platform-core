set -euo pipefail
cd /workspace/local/core-normalization-20261015/worktrees/backend-audit-node-assets
proof=/workspace/local/core-normalization-20261015/evidence/wave2-node-assets
npm --prefix node run build > "$proof/build.log" 2>&1
npm run contracts:test > "$proof/contracts-test.log" 2>&1
npm run validate:contracts > "$proof/validate-contracts.log" 2>&1
npm --prefix node run typecheck > "$proof/typecheck.log" 2>&1
npm --prefix node test -- --maxWorkers=1 --minWorkers=1 > "$proof/node-source.log" 2>&1
