import {readFileSync} from 'node:fs';import assert from 'node:assert/strict';
import {sign,verify} from '../../install/audit-jcs-node-assets-full/consumer/node_modules/@hideakisolutions/platform-node/dist/audit-jcs-v1/index.js';
const cases=JSON.parse(readFileSync(new URL('../../worktrees/backend-audit-node-assets/contracts/vendor/platform-core/e82ef12/audit/conformance/jcs-v1/vectors.json',import.meta.url)));
const vector=cases.find(x=>x.id==='utc-genesis');const result=sign(vector.raw);for(const key of ['hash','canonical_utf8','canonical_hex'])assert.equal(result[key],vector[key]);assert.equal(verify(JSON.stringify(result.entry)),true);
const invalid=JSON.parse(vector.raw);invalid.actor.name=3;assert.throws(()=>sign(JSON.stringify(invalid)),/structural/);
console.log('PASS installed renamed private-schema loading: pinned genesis bytes+verify; structural optional-field rejection');
