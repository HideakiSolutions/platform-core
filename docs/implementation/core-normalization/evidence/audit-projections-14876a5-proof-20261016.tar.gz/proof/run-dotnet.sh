#!/usr/bin/env bash
set -euo pipefail
export DOTNET_PROCESSOR_COUNT=2 MSBUILDDISABLENODEREUSE=1 DOTNET_CLI_USE_MSBUILD_SERVER=0 UseSharedCompilation=false
export ECP_CONTRACTS_ROOT=/workspace/local/core-normalization-20261015/worktrees/backend-next-integration
proof_dir=/workspace/local/core-normalization-20261015/evidence/audit-projections-14876a5
feed_dir=/workspace/local/core-normalization-20261015/artifacts/audit-projections-14876a5-dotnet
consumer_dir=/workspace/local/core-normalization-20261015/install/audit-projections-14876a5-dotnet
cd "$ECP_CONTRACTS_ROOT"
git rev-parse HEAD > "$proof_dir/source-head.txt"
if [ -n "$(git status --porcelain --untracked-files=all)" ]; then exit 31; fi
node scripts/contracts/verify-vendor.mjs > "$proof_dir/vendor.log" 2>&1
cd dotnet
dotnet test BackendCore.Dotnet.sln -c Release -m:1 -p:UseSharedCompilation=false --logger 'trx;LogFilePrefix=source' --results-directory "$proof_dir/source-results" > "$proof_dir/source.log" 2>&1
python3 "$proof_dir/verify-source-results.py" > "$proof_dir/source-validation.log" 2>&1
dotnet pack BackendCore.Dotnet.sln -c Release --no-build -m:1 -p:PackageOutputPath="$feed_dir" > "$proof_dir/pack.log" 2>&1
cd ..
python3 scripts/contracts/verify-installed-dotnet.py --root "$ECP_CONTRACTS_ROOT" --artifacts "$feed_dir" --output "$consumer_dir" --expected 966 --expected-projects 42 > "$proof_dir/installed.log" 2>&1
if [ "$(git rev-parse HEAD)" != "$(cat "$proof_dir/source-head.txt")" ] || [ -n "$(git status --porcelain --untracked-files=all)" ]; then exit 32; fi
