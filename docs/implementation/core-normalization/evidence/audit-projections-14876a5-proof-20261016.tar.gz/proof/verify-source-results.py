import hashlib,importlib.util,json,subprocess,sys,xml.etree.ElementTree as ET
from pathlib import Path
sys.dont_write_bytecode=True
source=Path('/workspace/local/core-normalization-20261015/worktrees/backend-next-integration')
output=Path('/workspace/local/core-normalization-20261015/evidence/audit-projections-14876a5')
spec=importlib.util.spec_from_file_location('installed_dotnet',source/'scripts/contracts/verify-installed-dotnet.py');proof=importlib.util.module_from_spec(spec);spec.loader.exec_module(proof)
projects={p.stem:str(p.relative_to(source)) for p in (source/'dotnet/tests').glob('*/*.csproj')}
if len(projects)!=42:raise ValueError('Source project profile must be42')
reports={}
for report in (output/'source-results').glob('*.trx'):
 root=ET.parse(report).getroot();method=root.find('{*}TestDefinitions/{*}UnitTest/{*}TestMethod')
 if method is None:raise ValueError('Source result lacks native test method')
 name=Path(method.get('codeBase','')).stem
 if name not in projects or projects[name] in reports:raise ValueError('Duplicate or unknown source project TRX')
 reports[projects[name]]=report
if set(reports)!=set(projects.values()):raise ValueError('Source selection mismatch')
rows=proof.verify_results(reports,42,966)
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
if revision!=(output/'source-head.txt').read_text().strip():raise ValueError('Source revision changed')
receipt={'status':'PASS','dimension':'source-default-dotnet-test-profile','source_revision':revision,'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source,text=True).strip(),'runtime':subprocess.check_output(['dotnet','--version'],text=True).strip(),'test_projects_expected':42,'test_projects_executed':len(rows),'cases_expected':966,'cases_executed':sum(row['count'] for row in rows),'skips':0,'project_results':rows,'source_log_sha256':proof.digest(output/'source.log'),'vendor_log_sha256':proof.digest(output/'vendor.log'),'validator_sha256':proof.digest(source/'scripts/contracts/verify-installed-dotnet.py'),'audit_corpus_sha256':proof.digest(source/'contracts/vendor/platform-core/e82ef12/audit/conformance/jcs-v1/vectors.json'),'limits':['Source profile only; installed artifacts proved separately','PostgreSQL Inbox integration outside default profile','No transport matrix certification, contract admission, publication or deployment']}
(output/'source-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ['status','test_projects_executed','cases_executed','skips']}))
