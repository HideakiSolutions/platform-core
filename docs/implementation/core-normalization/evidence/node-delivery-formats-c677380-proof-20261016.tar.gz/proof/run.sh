#!/usr/bin/env bash
set -euo pipefail
cd /workspace/local/core-normalization-20261015/worktrees/backend-delivery-format-integration
proof_dir=/workspace/local/core-normalization-20261015/evidence/delivery-format-c677380
if [ "$(git rev-parse HEAD)" != c677380f2fa2e964f09f0000ec075f29ba34b6c6 ] || [ -n "$(git status --porcelain --untracked-files=all)" ]; then exit 31; fi
node --version > "$proof_dir/node-version.txt"
npm ci --ignore-scripts --no-audit --no-fund > "$proof_dir/root-install.log" 2>&1
npm run contracts:verify > "$proof_dir/vendor.log" 2>&1
npm run contracts:test > "$proof_dir/contracts.log" 2>&1
npm run validate:contracts > "$proof_dir/validate-contracts.log" 2>&1
npm run validate:wave2-intakes > "$proof_dir/intakes.log" 2>&1
cd node
npm ci --ignore-scripts --no-audit --no-fund > "$proof_dir/node-install.log" 2>&1
npm run typecheck > "$proof_dir/typecheck.log" 2>&1
npm test -- --maxWorkers=2 --minWorkers=1 --reporter=json --outputFile="$proof_dir/source.json" > "$proof_dir/source.log" 2>&1
cd ..
PYTHONOPTIMIZE=2 python3 scripts/contracts/verify-installed-runtimes.py --source "$PWD" --output /workspace/local/core-normalization-20261015/install/delivery-format-c677380 --artifacts /workspace/local/core-normalization-20261015/artifacts/delivery-format-c677380 --stack node --expected 474 > "$proof_dir/installed.log" 2>&1
if [ "$(git rev-parse HEAD)" != c677380f2fa2e964f09f0000ec075f29ba34b6c6 ] || [ -n "$(git status --porcelain --untracked-files=all)" ]; then exit 32; fi
