from pathlib import Path
import hashlib,json,subprocess,re,tarfile,shutil,os
base=Path('/workspace/local/core-normalization-20261015');e=base/'evidence/delivery-format-c677380';s=base/'worktrees/backend-delivery-format-integration';o=base/'install/delivery-format-c677380';expected='c677380f2fa2e964f09f0000ec075f29ba34b6c6';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()!=expected or subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=s):raise RuntimeError('Source changed')
src=json.loads((e/'source.json').read_bytes());ins=json.loads((o/'tests.json').read_bytes());receipt=json.loads((o/'receipt.json').read_bytes());binding=json.loads((e/'source-binding.json').read_bytes())
if receipt['source_revision']!=expected or receipt['source_sha256']!=binding['tracked_source_sha256']:raise RuntimeError('Tracked source provenance differs')
if receipt['status']!='PASS' or receipt['cases_executed']!=474 or receipt['skips'] or len(receipt['resolution'])!=17:raise RuntimeError('Installed gate incomplete')
corpus=s/'contracts/vendor/platform-core/e82ef12/audit/conformance/jcs-v1/vectors.json'
if sha(corpus)!='3d4b5cd7680fa0db0639aec8961938771c715d642fdaffabcfeb853f6ee84da8':raise RuntimeError('Shared audit corpus changed')
ids=[c['id'] for c in json.loads(corpus.read_bytes())];dimensions=[]
for label,r in [('source',src),('installed',ins)]:
 if r['numTotalTests']!=474 or r['numPassedTests']!=474 or r['numFailedTests'] or r['numPendingTests'] or r.get('numTodoTests',0):raise RuntimeError('Node profile incomplete')
 def cases(name):return [a for f in r['testResults'] if f['name'].endswith('/'+name) for a in f['assertionResults']]
 fmt=cases('schema-formats.test.ts');delivery=cases('delivery-lease-corpus.test.ts');audit=cases('audit-jcs-v1.test.ts')
 if len(fmt)!=14 or len(delivery)!=16 or len(audit)!=39 or any(a['status']!='passed' for a in fmt+delivery+audit):raise RuntimeError('Mandatory named suites incomplete')
 if not all('backend-core/node-schema-formats/v1' in a['fullName'] for a in fmt):raise RuntimeError('Format profile identity missing')
 for id in ids:
  if sum(a['title']==id for a in audit)!=1:raise RuntimeError('Audit vector identity missing/duplicated: '+id)
 dimensions.append({'dimension':label,'total':474,'format_profile':'backend-core/node-schema-formats/v1','format_case_ids':[a['fullName'] for a in fmt],'delivery_case_ids':[a['fullName'] for a in delivery],'shared_audit_case_ids':ids})
text=(e/'contracts.log').read_text()
for name,expected_count in [('tests',46),('pass',46),('fail',0),('cancelled',0),('skipped',0),('todo',0)]:
 m=re.search(r'^# '+name+r' (\d+)$',text,re.M)
 if m is None or int(m[1])!=expected_count:raise RuntimeError('Contract suite incomplete: '+name)
references=[]
for label,root in [('source',s),('installed-fixture',o/'fixture')]:
 module=(root/'scripts/contracts/delivery-lease-corpus.mjs').as_uri();script='import {verifyDeliveryReference} from '+json.dumps(module)+'; console.log(JSON.stringify(await verifyDeliveryReference('+json.dumps(str(root))+')));'
 proc=subprocess.run(['node','--input-type=module','-e',script],capture_output=True,text=True)
 (e/(label+'-delivery-reference.log')).write_text(proc.stdout+proc.stderr)
 if proc.returncode:raise RuntimeError('Reference model failed: '+label)
 ref=json.loads(proc.stdout)
 if ref['result']!='PASS' or ref['executed_cases']!=18 or ref['executed_steps']!=58 or ref['skips'] or ref['adapter_durability']!='NOT_VERIFIED':raise RuntimeError('Reference dimensions conflated')
 (e/(label+'-delivery-reference.json')).write_text(json.dumps(ref,indent=2)+'\n');references.append({'dimension':label,'receipt_sha256':sha(e/(label+'-delivery-reference.json')),'cases':18,'steps':58,'adapter_durability':'NOT_VERIFIED'})
shutil.copy2(o/'receipt.json',e/'installed-receipt.json');shutil.copy2(o/'tests.json',e/'installed-tests.json')
artifact=Path(receipt['artifacts'][0]['path'])
with tarfile.open(artifact) as t:members=[m for m in t.getmembers() if m.isfile()]
plugin=json.loads((o/'consumer/node_modules/ajv-formats/package.json').read_bytes())['version']
if plugin!='3.0.1':raise RuntimeError('Wrong format module')
summary={'status':'PASS','source_revision':expected,'tracked_source_sha256':receipt['source_sha256'],'runtime':receipt['runtime'],'source_cases':474,'installed_cases':474,'skips':0,'contract_guard_tests':46,'typecheck':'PASS','format_plugin':'ajv-formats@3.0.1/full','dimensions':dimensions,'reference_dimensions':references,'exports':17,'archive_members':len(members),'artifact':receipt['artifacts'][0],'source_report_sha256':sha(e/'source.json'),'installed_report_sha256':sha(o/'tests.json'),'installed_receipt_sha256':sha(o/'receipt.json'),'limits':['Reference18/58 is canonical memory state-machine model; not a durable adapter','Structural validation, behavior, installation and transport proofs are separate','Five-runtime CI closure remains required after vendor distribution expansion','No registry adoption, contract owner admission, durable transport or production deployment claim']}
(e/'closure-receipt.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[(p,'proof/'+p.name) for p in sorted(e.iterdir()) if p.is_file() and p.name not in ['proof.tar.gz','manifest.json']]
files.extend((p,'installed-logs/'+p.name) for p in sorted(o.glob('*.log')));files.append((artifact,'artifact/'+artifact.name))
manifest={'schema_version':1,'source_revision':expected,'members':[{'path':n,'sha256':sha(p),'bytes':p.stat().st_size} for p,n in files]}
with tarfile.open(e/'proof.tar.gz','w:gz') as t:
 for p,n in files:t.add(p,arcname=n,recursive=False)
manifest['archive']={'path':'proof.tar.gz','sha256':sha(e/'proof.tar.gz'),'bytes':(e/'proof.tar.gz').stat().st_size};(e/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'status':'PASS','source':474,'installed':474,'format':14,'delivery':16,'shared_audit':33,'references':references,'archive':manifest['archive'],'manifest_sha256':sha(e/'manifest.json')},indent=2))
