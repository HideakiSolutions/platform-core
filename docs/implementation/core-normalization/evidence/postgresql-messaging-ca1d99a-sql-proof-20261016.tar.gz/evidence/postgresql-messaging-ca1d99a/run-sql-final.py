"""Final exact-head storage profiles; invoked once under a single heavy-run lock."""
import datetime,hashlib,json,os,pathlib,subprocess,sys
base=pathlib.Path('/workspace/local/core-normalization-20261015')
source=base/'worktrees/backend-postgresql-messaging-integration'
evidence=base/'evidence/postgresql-messaging-ca1d99a'
expected='ca1d99ac0415ee6e0a7ba813c41ae5cfc5490fee'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=source)
def snapshot():
 if git('status','--porcelain','--untracked-files=all').strip():raise RuntimeError('Source is not clean; no further SQL proof permitted')
 if git('rev-parse','HEAD').decode().strip()!=expected:raise RuntimeError('Source revision changed')
 digest=hashlib.sha256()
 for name in sorted(filter(None,git('ls-files','-z').decode().split('\0'))):
  p=source/name;raw=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
  digest.update(name.encode()+b'\0'+hashlib.sha256(raw).digest())
 return digest.hexdigest()
record={'kind':'final-integrated-postgresql-storage-proofs/v1','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_revision':expected,'source_fingerprint_before':snapshot(),'credential_cadence':{'stored_reference':'pass/core-normalization/postgres-inbox-20261016','read_count':1,'read_phase':'inside exclusive heavy-run lock, immediately before serial helper executions','disclosure':'secret captured in process memory only; never printed or passed as CLI argument','provisioning':'none; existing program role/schema only'},'phases':[],'status':'RUNNING','limits':['Storage-only profiles; no broker integration or ten-cell durability admission','Prior76/fad receipts remain separate historical revisions; no relabeling','Full977 default/installed proof is separate and not repeated by this runner']}
def save():(evidence/'runner-receipt.json').write_text(json.dumps(record,indent=2)+'\n')
save()
# Credential was previously stored by program provisioning. No new secret is created.
secret=subprocess.check_output(['pass','show','core-normalization/postgres-inbox-20261016'],text=True).splitlines()[0]
connection='Host=10.43.112.253;Port=5432;Database=postgres;Username=core_normalization_inbox_20261016;Password="'+secret.replace('"','""')+'";Include Error Detail=false;Timeout=10;Command Timeout=15'
try:
 for stack,count in [('inbox',10),('outbox',19)]:
  if snapshot()!=record['source_fingerprint_before']:raise RuntimeError('Tracked source bytes changed before phase')
  output=base/('install/messaging-ca1d99a-'+stack);feed=base/('artifacts/messaging-ca1d99a-'+stack)
  env=os.environ.copy();env['DOTNET_PROCESSOR_COUNT']='2';env['PLATFORM_POSTGRES_'+stack.upper()+'_CONNECTION']=connection;env['PLATFORM_POSTGRES_'+stack.upper()+'_SCHEMA']='core_normalization_20261016_inbox'
  command=['python3',str(source/('scripts/contracts/verify-installed-postgresql-'+stack+'.py')),'--source',str(source),'--output',str(output),'--artifacts',str(feed),'--expected',str(count)]
  process=subprocess.run(command,cwd=source,env=env,capture_output=True,text=True)
  text=process.stdout+process.stderr
  if secret in text or connection in text:raise RuntimeError('Credential redaction guard; output withheld')
  log=evidence/(stack+'-helper.log');log.write_text(text)
  phase={'stack':stack,'expected':count,'exit_code':process.returncode,'log':str(log),'log_sha256':sha(log)};record['phases'].append(phase);save()
  if process.returncode:raise RuntimeError(stack+' helper failed; see redacted phase log')
  receipt=output/'receipt.json';value=json.loads(receipt.read_text())
  if value['status']!='PASS' or value['source_revision']!=expected or value['tests']['executed']!=count or value['tests']['skips']!=0 or value['negative_configuration']['failed']!=count:raise RuntimeError('Incomplete exact-head profile')
  for position in ['database_before','database_after']:
   check=value[position]
   if check['schema_objects']!=0 or check['schema_owner'] is not True or check['administrative_flags'] is not False:raise RuntimeError('Restricted empty schema invariant failed')
  phase.update(status='PASS',receipt=str(receipt),receipt_sha256=sha(receipt),cases_executed=count,missing_configuration_expected_failures=count,skips=0,artifacts=value['artifacts']);save()
  print(json.dumps({'phase':stack,'status':'PASS','source_revision':expected,'cases':count,'skips':0}),flush=True)
 record['source_fingerprint_after']=snapshot()
 if record['source_fingerprint_after']!=record['source_fingerprint_before']:raise RuntimeError('Source changed across final proof cadence')
 record['status']='PASS';record['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
except Exception as error:
 record['status']='BLOCKED';record['failure']=str(error);save();print('BLOCKED: final SQL proof; see external runner receipt',file=sys.stderr);sys.exit(1)
