import os, json, shutil, subprocess, tempfile, pathlib, hashlib, zipfile
base=pathlib.Path('/workspace/local/core-normalization-20261015')
proof=base/'install/audit-jcs-go-bd63d5b'
logs=base/'evidence/audit-jcs-go/bd63d5b'
go=str(base/'toolchains/go1.26.8/go/bin/go')
module='github.com/hideakisolutions/backend-core/golang'
env={k:v for k,v in os.environ.items() if k not in ['GOWORK','GOFLAGS']}
env.update(GOMAXPROCS='2',GOWORK='off',GOMODCACHE=str(proof/'modcache'),GOPROXY=(base/'artifacts/audit-jcs-go-bd63d5b/proxy').as_uri()+',https://proxy.golang.org',GOSUMDB='off')
results=[]
def check(name, command, runenv, expected):
 p=subprocess.run(command,cwd=proof/'consumer',env=runenv,text=True,capture_output=True)
 payload=p.stdout+p.stderr
 (logs/(name+'.log')).write_text(payload)
 if p.returncode==0 or expected not in payload:raise RuntimeError(name+' did not fail for expected reason: '+payload)
 results.append({'case':name,'exit_code':p.returncode,'required_error':expected,'log_sha256':hashlib.sha256(payload.encode()).hexdigest(),'verdict':'PASS_EXPECTED_REJECTION'})
with tempfile.TemporaryDirectory(prefix='audit-jcs-go-negative-',dir=base/'install') as scratch:
 root=pathlib.Path(scratch)
 for name,mutation in [('corpus-missing',None),('corpus-empty',b'[]\n'),('corpus-tampered',b'[{}]\n')]:
  fixture=root/name;shutil.copytree(proof/'fixture',fixture)
  corpus=fixture/'contracts/vendor/platform-core/e82ef12/audit/conformance/jcs-v1/vectors.json'
  if mutation is None:corpus.unlink()
  else:corpus.write_bytes(mutation)
  caseenv=env|{'ECP_CONTRACTS_ROOT':str(fixture)}
  check(name,[go,'test','-mod=mod','-count=1','-p','1','-run','^TestPinnedCorpus$',module+'/audit/jcsv1'],caseenv,'pinned contract integrity gate')
 cache=root/'tampered-modcache';shutil.copytree(proof/'modcache',cache)
 receipt=json.loads((proof/'receipt.json').read_text());relative=pathlib.Path(receipt['resolution']['Dir']).relative_to(proof/'modcache')
 target=cache/relative/'audit/jcsv1/_assets/audit-event.schema.json';target.chmod(target.stat().st_mode|0o200);target.write_bytes(target.read_bytes()+b'\n')
 check('packaged-schema-tampered',[go,'test','-mod=mod','-count=1','-p','1','-run','^TestPinnedCorpus/utc-genesis$',module+'/audit/jcsv1'],env|{'ECP_CONTRACTS_ROOT':str(proof/'fixture'),'GOMODCACHE':str(cache)},'audit schema integrity mismatch')
 helper=base/'worktrees/backend-runtime-guards/scripts/contracts/verify-installed-runtimes.py'
 check('expected-zero',['python3',str(helper),'--source',str(base/'worktrees/backend-audit-go'),'--output',str(root/'zero-install'),'--artifacts',str(root/'zero-artifacts'),'--stack','go','--expected','0','--go',go],env|{'PYTHONOPTIMIZE':'2'},'Expected cases must be positive')
(logs/'negative-results.json').write_text(json.dumps({'source_revision':json.loads((proof/'receipt.json').read_text())['source_revision'],'results':results,'temporary_fixture_cleanup':'complete'},indent=2)+'\n')
print(json.dumps(results))
