# Incorporação delimitada dos330 registros históricos

O levantamento original foi reconciliado como insumo histórico em465ac78700d5257163e0a0929750c3a0598f671b, checkout limpo. As quatro definições somam125+120+68+17=330 IDs únicos; registry, triage e matriz de uso têm exatamente o mesmo conjunto. Os oito hashes de entrada da triagem conferem.

Isso corrige somente a observação atual: o baseline congelado de20261015 permanece intacto. Aquele baseline usou o catálogo de787 candidatos/179 repositórios como pista histórica; esse catálogo é outro dataset e não fundamenta a contagem330.

A triagem continua all-records-triaged-proposal:330 decisões não aprovadas, implementação não certificada e extração não aprovada; revisão independente histórica pendente. Decisões propostas: compose171, domain-local16, extract14, extend-core116 e reuse-core13. Os20 source-decisions são propostas, não concessões de autoridade.

A releitura delimitada de auditoria, transação de consumo/publicação, tokens e contexto tenant preserva seus limites: leitores históricos, adaptação versionada, rollback real, provenance de tokens, instalação independente e tenant verificável. Para52 caminhos históricos pertinentes,42 ainda têm bytes iguais; diferenças ou ausências ficam explícitas no recibo. Igualdade de arquivo não demonstra runtime, uso, adoção ou conformidade atual.

As entregas atuais usam provas próprias por revisão, já revisadas separadamente. O arquivo current-delivery-destinations.json consulta merges reais dos cinco cores e registra candidatos backend separados; templates seguem bloqueados sem nova prova. Isso não classifica semanticamente todas as branches nem dá destino de implementação aprovado aos330 registros. Nenhum grafo canônico foi alterado, e nenhuma certificação ou adoção foi inferida.
